import { createContext } from "react";
const context = createContext();
export const { Provider, Consumer } = context;
export default context;