import React, {
    useCallback,
    useState,
    useEffect,
    Fragment,
    useContext,
  } from "react";
  import "./Footer.scss";
  import { Provider } from "../context";
import * as R from "ramda";
import context from "./../context";
  
  const Footer = (props) => {
    const contextValue = useContext(context);
    const { isDarkMode} = contextValue;
    const {footerStyle} = props;
  
useEffect(() => {
  console.log('footerStyle123', footerStyle)

}, []);






    return (
    <Fragment>
    {footerStyle === "footerAnother"? (
    <div className="footer_container">
      <div className={`footer_area ${isDarkMode ? "footer_area_dark":""}`}>
        <div className="copy_right_area">
            <div className="copy_right_text_a">Copyright&nbsp;&nbsp;2022&nbsp;&nbsp;Love&Peace&nbsp;&nbsp;Rock&nbsp;&nbsp;Festival.&nbsp;&nbsp;All&nbsp;&nbsp;rights&nbsp;&nbsp;reserved.
            </div>
            <div className="copy_right_text_b">The website is developed and designed by me, powered by react.js
          </div>
        </div>
        <div className="icon_area">
            <div className="icon ig_icon"></div>
            <div className="icon fb_icon"></div>
        </div>
      </div>
    </div>
     
    ):(
    <div className="footer_container">
        <div className={`footer_area_two ${isDarkMode ? "footer_area_dark":""}`}>
          <div className="copy_right_area">
              <div className="copy_right_text_a">Copyright&nbsp;&nbsp;2022&nbsp;&nbsp;Love&Peace&nbsp;&nbsp;Rock&nbsp;&nbsp;Festival.&nbsp;&nbsp;All&nbsp;&nbsp;rights&nbsp;&nbsp;reserved.
              </div>
              <div className="copy_right_text_b">The website is developed and designed by me, powered by react.js
            </div>
          </div>
          <div className="icon_area">
              <div className="icon ig_icon"></div>
              <div className="icon fb_icon"></div>
          </div>
        </div>
      </div> 
    )
    }
    </Fragment>
  );
  };
  export default Footer;