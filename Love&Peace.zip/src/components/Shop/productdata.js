const Product_card=[
    {id:'1',
      name:'Logo T-shirt',
      slug:'LogoT-shirt',
      size:['S','M','L'],
      color:['Black','White','Red'],
      price:550,
      image:require('../Shop/shopImage/LoTshirt-black.png'),
     
             
      // '../Shop/shopImage/LoTshirt-red.png',
      // '../Shop/shopImage/LoTshirt-white.png'),
       
    },
    {id:'2',
      name:'Logo Hoodie',
      slug:'LogoHoodie',
      size:['S','M','L'],
      color:'Black',
      price:1050,
      image:require('../Shop/shopImage/LoHoodie-black.png'),
      // '../ItemPage/Itemimage/LoHoodie-red.png',
      // '../ItemPage/Itemimage/LoHoodie-white.png')
    },
    {id:'3',
      name:'Logo Cap',
      slug:'LogoCap',
      color:'White',
      price:650,
      image:require('../Shop/shopImage/LoCap-white.png')
    },
    {id:'4',
      name:'Logo Mask',
      slug:'LogoMask',
      price:150,
      image:require('../Shop/shopImage/LoMask.png')
    },
    {id:'5',
    name:'Logo Towel',
    slug:'LogoTowel',
    price:250,
    image:require('../Shop/shopImage/LoTowel.png')
    },
    {id:'6',
    name:'Logo Cup',
    slug:'LogoCup',
    price:350,
    image:require('../Shop/shopImage/LoCup.png')
    },
    {id:'7',
    name:'Logo Towel',
    slug:'LogoTowel',
    price:250,
    image:require('../Shop/shopImage/LoTowel.png')
    },
    {id:'8',
    name:'Logo Picnic Mat',
    slug:'LogoPicnic Mat',
    price:750,
    image:require('../Shop/shopImage/LoPicnicMat.png')
    },
    {id:'9',
    name:'Logo Opener',
    slug:'LogoOpener',
    price:390,
    image:require('../Shop/shopImage/LoOpener.png')
    },
    {id:'10',
    name:'Logo Bag',
    slug:'LogoBag',
    price:450,
    image:require('../Shop/shopImage/LoBag.png')
    },
    {id:'11',
    name:'Logo Card Holder',
    slug:'LogoCard Holder',
    price:580,
    image:require('../Shop/shopImage/LoCardHolder.png')
    },
    {id:'12',
    name:'Logo Sleeve',
    slug:'LogoSleeve',
    price:120,
    image:require('../Shop/shopImage/LoSleeve.png')
    },
    {id:'13',
    name:'Logo Pillow',
    slug:'LogoPillow',
    price:690,
    image:require('../Shop/shopImage/LoPillow.png')
    },
    {id:'14',
    name:'Logo Raincoat',
    slug:'LogoRaincoat',
    price:350,
    image:require('../Shop/shopImage/LoRaincoat.png')
    },
    {id:'15',
    name:'Logo Phonecase',
    slug:'LogoPhonecase',
    price:380,
    image:require('../Shop/shopImage/LoPhonecase.png')
    },
    {id:'16',
    name:'Logo Bottle',
    slug:'LogoBottle',
    price:380,
    image:require('../Shop/shopImage/LoBottle.png')
    },

  ]
  export default Product_card;

