// import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
// import "./ItemPage.scss"
// import { FaShoppingCart, FaRegHeart } from 'react-icons/fa';
// import { Carousel } from "react-bootstrap";
// import { Button } from "react-bootstrap";
// import Image from 'react-bootstrap/Image';
// import product_data from '../Shop/productdata';
// // import context from "../context";
// import { createContext } from "react";
// import context,{Provider} from "react-bootstrap/esm/AccordionContext";



// const Add_Item = ({ item, cart, setCart }) => {

//      const addToCart = (evt) => {
//          console.log(evt.target.name)
//          setCart([...cart, item])
//         }

     
//         // const ItemDetails = React.createContext();




//     return (
//         <>
//         {/* <ItemDetails.Provider value={}> */}
//         <div className="product_info" key={item.id}>
//             <div className="product_carousel" >
//                 <Image className="carousel_img" src={item.image}></Image>
//             </div>
//             <div className="product-details">
//                 <h6>{item.name}</h6>
//                 <h6>{item.price}</h6>
//             </div>

//             <div className="order_button">
//                 <Button variant="outline-secondary" size="sm" ><FaShoppingCart />Add to cart</Button>
//             </div>
//         </div>
//         {/* </ItemDetails.Provider> */}
//         </>
        
//     )
// }
// export default Add_Item;
